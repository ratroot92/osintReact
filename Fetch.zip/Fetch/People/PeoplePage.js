import React,{Component} from 'react';





import FetchNavbar from './../FetchNavbar';
class PeoplePage extends Component{


	render(){

		return (<div className="">
			<FetchNavbar/>
			</div>
			)
	}
}
export default PeoplePage;